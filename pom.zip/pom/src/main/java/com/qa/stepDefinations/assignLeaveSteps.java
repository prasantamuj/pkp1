package com.qa.stepDefinations;

import com.qa.pages.homePage;
import com.qa.pages.loginPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class assignLeaveSteps {
	
	
	loginPage lp= new loginPage();
	homePage hp= new homePage();
	
	@When("^Employee enters his/her name$")
	public void employee_enters_his_her_name() throws Throwable {
	//	homePage hp= new homePage();
		hp.enterEmployee();
	}

	@When("^Select his leave type$")
	public void select_his_leave_type() throws Throwable {
	    
	}

	@When("^Select from date and to date$")
	public void select_from_date_and_to_date() throws Throwable {
	   
	}

	@When("^Select the partial days$")
	public void select_the_partial_days() throws Throwable {
	    
	}

	@When("^enter comment$")
	public void enter_comment() throws Throwable {
	   
	}

	@When("^Click on the assign Button$")
	public void click_on_the_assign_Button() throws Throwable {
	   
	}

	@Then("^Check the validations$")
	public void check_the_validations() throws Throwable {
	   
	}

}
