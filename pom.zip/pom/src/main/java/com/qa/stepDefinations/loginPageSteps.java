package com.qa.stepDefinations;

import com.qa.pages.homePage;
import com.qa.pages.loginPage;
import com.qa.util.BaseClass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class loginPageSteps extends BaseClass {
	
	loginPage lp= new loginPage();
	homePage hp= new homePage();
	String userName= prop.getProperty("username");
	String Password= prop.getProperty("password");
	@Given("^useris on the login page$")
	public void useris_on_the_login_page() throws Throwable {
		BaseClass.initialization();
		System.out.println("Opening the Browser");
	    
	}

	@When("^user entered username and password$")
	public void user_entered_username_and_password() throws Throwable {
		lp = new loginPage();
		lp.validateLoginPageTitle();
		System.out.println("Validate login page title " +lp.validateLoginPageTitle());
		Thread.sleep(5000);
		hp= lp.login(userName,Password);
	    
	}


	@Then("^home page is dispaled$")
	public void home_page_is_dispaled() throws Throwable {
	   hp= new homePage();
		hp.clickd(); 
	}

}
// ctrl+shift+o