package com.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.BaseClass;

public class homePage extends BaseClass {
	@FindBy(xpath="//*[@id=\"dashboard-quick-launch-panel-menu_holder\"]/table/tbody/tr/td[1]/div/a/img")
	WebElement ClickAssignLeave;
	@FindBy(xpath="//input[@id='assignleave_txtEmployee_empName']")
	WebElement Employee;
	
	public homePage() 
	{
		PageFactory.initElements(driver, this);
		
	 }
	
	public void clickd ()
	{
		
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", ClickAssignLeave);
			
}
	public void enterEmployee() {
		Employee.sendKeys("Prasanta");
	}
}
