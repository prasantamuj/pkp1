package com.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.BaseClass;

public class loginPage extends BaseClass {
	// Page Factory -OR
	@FindBy(xpath="//input[@id='txtUsername']")
	WebElement username;
	
	@FindBy(xpath="//input[@id='txtPassword']")
	WebElement password;
	
	@FindBy(xpath="//input[@id='btnLogin']")
	WebElement loginbwn;
	
	//initializing the Page objects:
	
	public loginPage() 
	{
		PageFactory.initElements(driver, this);
	
		
	 }
	// Actions:
		public String validateLoginPageTitle() 
		{
			return driver.getTitle();
		}
		
		public homePage login (String un, String pw)
		{
			username.sendKeys(un);
			password.sendKeys(pw);
			JavascriptExecutor js= (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", loginbwn);
			return new homePage();
		
	}

}
